#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

namespace
{
    const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";

    GLFWwindow* g_Window = nullptr;
    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

// Forward decl
static bool InitializeGLFW();
static bool InitializeGLEW();

// Optional but helpful: keep viewport correct on resize
static void FramebufferSizeCallback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

int main(int argc, char* argv[])
{
    if (!InitializeGLFW())
        return EXIT_FAILURE;

    g_ShaderManager = new ShaderManager();
    g_ViewManager = new ViewManager(g_ShaderManager);

    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
    if (!g_Window)
    {
        glfwTerminate();
        return EXIT_FAILURE;
    }

    // ? GUARANTEE the OpenGL context is current BEFORE glewInit()
    glfwMakeContextCurrent(g_Window);

    // Optional but recommended (vsync)
    glfwSwapInterval(1);

    // ? Now init GLEW (function pointers become valid)
    if (!InitializeGLEW())
    {
        glfwTerminate();
        return EXIT_FAILURE;
    }

    // Load + use shaders AFTER GLEW
    g_ShaderManager->LoadShaders(
        "../../Utilities/shaders/vertexShader.glsl",
        "../../Utilities/shaders/fragmentShader.glsl"
    );
    g_ShaderManager->use();

    // Scene AFTER shaders + GLEW + context
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);
        glClearColor(0.05f, 0.05f, 0.08f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_ViewManager->PrepareSceneView();
        g_SceneManager->RenderScene();

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    delete g_SceneManager;  g_SceneManager = nullptr;
    delete g_ViewManager;   g_ViewManager = nullptr;
    delete g_ShaderManager; g_ShaderManager = nullptr;

    glfwTerminate();
    return EXIT_SUCCESS;
}


static bool InitializeGLFW()
{
    if (!glfwInit())
    {
        std::cerr << "GLFW init failed.\n";
        return false;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    return true;
}

static bool InitializeGLEW()
{
    glewExperimental = GL_TRUE;

    GLenum result = glewInit();
    if (result != GLEW_OK)
    {
        std::cerr << "GLEW init failed: " << glewGetErrorString(result) << "\n";
        return false;
    }

    // GLEW can trigger a harmless GL error on init
    glGetError();

    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n\n";
    return true;
}
