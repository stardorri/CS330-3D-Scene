///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Angel Silva - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////


#include "SceneManager.h"
#include <iostream>
#include <glm/gtx/transform.hpp>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // prevent garbage value causing texture bind chaos
    m_loadedTextures = 0;

    // clear texture slots
    for (int i = 0; i < 16; i++)
    {
        m_textureIDs[i].ID = 0;
        m_textureIDs[i].tag = "";
    }
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;

    DestroyGLTextures();

    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    if (m_loadedTextures >= 16)
    {
        std::cout << "Too many textures loaded (max 16). Skipping: " << filename << "\n";
        return false;
    }

    int width = 0, height = 0, channels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (!image || width <= 0 || height <= 0)
    {
        std::cout << "Failed to load texture: " << filename << "\n";
        return false;
    }

    GLenum format = 0;
    GLenum internalFormat = 0;

    if (channels == 3)
    {
        format = GL_RGB;
        internalFormat = GL_RGB8;
    }
    else if (channels == 4)
    {
        format = GL_RGBA;
        internalFormat = GL_RGBA8;
    }
    else
    {
        std::cout << "Unsupported channel count (" << channels << "): " << filename << "\n";
        stbi_image_free(image);
        return false;
    }

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // IMPORTANT for RGB images (3 channels)
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, width, height, 0,
        format, GL_UNSIGNED_BYTE, image);

    glGenerateMipmap(GL_TEXTURE_2D);

    // Optional: restore default for other uploads
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

    // Free CPU image data immediately after upload
    stbi_image_free(image);

    glBindTexture(GL_TEXTURE_2D, 0);


    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}


/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures() const
{
    // Bind each loaded texture to a unique texture unit (0..15)
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].ID != 0)
        {
            glDeleteTextures(1, &m_textureIDs[i].ID);
            m_textureIDs[i].ID = 0;
            m_textureIDs[i].tag = "";
        }
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag.compare(tag) == 0)
        {
            return m_textureIDs[i].ID;
        }
    }
    return -1;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag.compare(tag) == 0)
        {
            return i;
        }
    }
    return -1;
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
        return false;

    for (int i = 0; i < (int)m_objectMaterials.size(); i++)
    {
        if (m_objectMaterials[i].tag.compare(tag) == 0)
        {
            material = m_objectMaterials[i];
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 model = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setMat4Value(g_ModelName, model);
    }
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));

        // ADD THIS so lighting has something to light
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(r, g, b));
    }
}


/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int slot = FindTextureSlot(textureTag);
        // If tag wasn't found, do NOT change the sampler (prevents invalid sampling)
        if (slot >= 0)
        {
            m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
        }
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Controls UV tiling. (This is where your "complex texturing
 *  technique" requirement is satisfied when you set values > 1.)
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (!m_pShaderManager) return;

    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material))
    {
        // ADD THESE (this is the big missing piece)
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);

        // You already had these
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}



/***********************************************************
 *  LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    // NOTE: these paths must match your folder structure
    CreateGLTexture("../../Utilities/textures/floor.jpg", "floorTex");
    CreateGLTexture("../../Utilities/textures/metal.jpg", "metalTex");
    CreateGLTexture("../../Utilities/textures/shade.jpg", "shadeTex");
    CreateGLTexture("../../Utilities/textures/base.jpg", "baseTex");

    BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    OBJECT_MATERIAL mat;
    mat.ambientColor = glm::vec3(1.0f);
    mat.diffuseColor = glm::vec3(1.0f);
    mat.specularColor = glm::vec3(1.0f);
    mat.shininess = 32.0f;
    mat.ambientStrength = 0.35f;
    mat.tag = "LightingMaterial";

    m_objectMaterials.push_back(mat);
}


/***********************************************************
 *  SetupSceneLights()
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    if (!m_pShaderManager) return;

    // Turn lighting ON in the shader
    m_pShaderManager->setBoolValue("bUseLighting", true);

    // --- Directional light (ON) ---
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);
    m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.2f, -1.0f, -0.3f));
    m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(1.00f, 1.00f, 1.00f));
    m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(1.00f, 1.00f, 1.00f));
    m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(1.00f, 1.00f, 1.00f));

    // --- Point lights: turn ALL off first (prevents garbage lights) ---
    for (int i = 0; i < 5; i++)
    {
        std::string base = "pointLights[" + std::to_string(i) + "].";
        m_pShaderManager->setBoolValue((base + "bActive").c_str(), false);
        m_pShaderManager->setVec3Value((base + "ambient").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setVec3Value((base + "diffuse").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setVec3Value((base + "specular").c_str(), glm::vec3(0.0f));
    }

    // --- Point light 0 (ON) ---
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
    m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(2.0f, 4.0f, 2.0f));
    m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.08f));
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.90f));
    m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.00f));

    // --- Point light 1 (ON, warm fill) ---
    m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
    m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-3.0f, 2.0f, -2.0f));
    m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.06f, 0.05f, 0.04f));
    m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.85f, 0.70f, 0.55f));
    m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.90f, 0.80f, 0.70f));

    // --- Spotlight OFF (unless you want it) ---
    m_pShaderManager->setBoolValue("spotLight.bActive", false);
}


/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    //SetupSceneLights();
    LoadSceneTextures();   // <-- COMMENT THIS OUT for now (safe mode)

    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
}


/***********************************************************
 *  RenderScene()
 *
 *  Milestone 4 requirements covered here:
 *  - Floor plane has tiled texture (complex technique)
 *  - One complex object composed of multiple shapes with different textures
 ***********************************************************/
void SceneManager::RenderScene()
{
    // IMPORTANT: lighting uniforms must be sent while the shader program is active.
    SetupSceneLights();

    if (m_pShaderManager)
        m_pShaderManager->setBoolValue("bUseLighting", false);

    SetShaderMaterial("LightingMaterial");



    // ----------------------------
    // Floor
    // ----------------------------
    SetTransformations(
        glm::vec3(20.0f, 1.0f, 20.0f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.0f, 0.0f)
    );
    SetShaderColor(0.45f, 0.45f, 0.45f, 1.0f);   // dark gray floor
    m_basicMeshes->DrawPlaneMesh();

    // ----------------------------
    // LAMP (placed near center so camera likely sees it)
    // ----------------------------

// ----------------------------
// LAMP (more obvious shape)
// ----------------------------

// 1) Base (wide cylinder + a thin "foot" ring)
    SetTransformations(
        glm::vec3(2.1f, 0.18f, 2.1f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.18f, 0.0f)
    );
    SetShaderColor(0.30f, 0.30f, 0.30f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Foot ring (slightly wider, very thin)
    SetTransformations(
        glm::vec3(2.35f, 0.06f, 2.35f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.06f, 0.0f)
    );
    SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();


    // 2) Stem (thinner + taller)
// Pole (connects to base)
    SetTransformations(
        glm::vec3(0.12f, 3.6f, 0.12f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.24f, 0.0f)
    );
    SetShaderColor(0.55f, 0.55f, 0.55f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();




    // 3) Collar under shade (small cylinder to transition)
    SetTransformations(
        glm::vec3(0.55f, 0.20f, 0.55f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 3.55f, 0.0f)
    );
    SetShaderColor(0.20f, 0.18f, 0.12f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();


    // 4) Shade (bigger + slightly taller; sits lower)
    SetTransformations(
        glm::vec3(2.4f, 1.6f, 2.4f),
        0.0f, 0.0f, 0.0f,          // <-- FIX: no 180
        glm::vec3(0.0f, 4.25f, 0.0f)
    );
    m_basicMeshes->DrawConeMesh();

    // 5) Bulb (tucked up inside the shade)
    SetTransformations(
        glm::vec3(0.65f, 0.65f, 0.65f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 3.95f, 0.0f)
    );
    SetShaderColor(0.95f, 0.95f, 0.85f, 1.0f);
    m_basicMeshes->DrawSphereMesh();


    // 6) Cap / finial on top of shade (small cylinder + tiny sphere)
    SetTransformations(
        glm::vec3(0.22f, 0.18f, 0.22f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 4.95f, 0.0f)
    );
    SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    SetTransformations(
        glm::vec3(0.18f, 0.18f, 0.18f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 5.12f, 0.0f)
    );
    SetShaderColor(0.30f, 0.30f, 0.30f, 1.0f);
    m_basicMeshes->DrawSphereMesh();


    // 7) Switch on base (move it to the edge so it reads better)
    SetTransformations(
        glm::vec3(0.28f, 0.12f, 0.28f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(1.25f, 0.32f, 0.15f)
    );
    SetShaderColor(0.85f, 0.10f, 0.10f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

}

